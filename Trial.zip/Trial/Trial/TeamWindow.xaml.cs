﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for TeamWindow.xaml
    /// </summary>
    public partial class TeamWindow : Window
    {
        public TeamWindow()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Sep19CHNEntities contextObj = new Trial.Sep19CHNEntities();
                Team1 teamToBeDeleted = new Trial.Team1();


                int Team_Id = Convert.ToInt32(txt_id.Text);
                teamToBeDeleted = contextObj.Team1.FirstOrDefault(team => team.Team_Id == Team_Id);
                if (teamToBeDeleted != null)
                {
                    contextObj.Team1.Remove(teamToBeDeleted);//Delete operation
                    contextObj.SaveChanges();//Save the changes ack to the db
                    MessageBox.Show("Team Details Deleted");
                }
                else throw new Exception("Delete could not be done!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnList_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new Trial.Sep19CHNEntities();


            var query3 = from Team1 team in contextObj.Team1
                         //where team.Customer_Region == txt_custLocation.Text
                         select team;


            List<Team1> tlist = new List<Trial.Team1>();
            tlist = query3.ToList<Team1>();
            if (tlist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            {
                dgTeam.ItemsSource = tlist;// query3.ToList();
            }
        }

        private void dgTeam_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    Sep19CHNEntities contextObj = new Trial.Sep19CHNEntities();
            //    Team1 teamToBeSearched = new Trial.Team1();


            //    int Team_Id = Convert.ToInt32(txt_id.Text);
            //    teamToBeSearched = contextObj.Team1.FirstOrDefault(team => team.Team_Id == Team_Id);
            //    if (teamToBeSearched != null)
            //    {
            //        contextObj.Team1.ToList<Team1>;//Delete operation
            //        contextObj.SaveChanges();//Save the changes ack to the db
            //        MessageBox.Show("Team Details Deleted");
            //    }
            //    else throw new Exception("Delete could not be done!");
            //}

            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    Sep19CHNEntities contextObj = new Trial.Sep19CHNEntities();
            //    Team1 customerRow = MyDataGrid.SelectedItem as Customer;
            //    string m = customerRow.CustomerID;
            //    Customer customer = (from p in dataContext.Customers
            //                         where p.CustomerID == customerRow.CustomerID
            //                         select p).Single();
            //    customer.CompanyName = customerRow.CompanyName;
            //    customer.ContactName = customerRow.ContactName;
            //    customer.Country = customerRow.Country;
            //    customer.City = customerRow.City;
            //    customer.Phone = customerRow.Phone;
            //    dataContext.SubmitChanges();
            //    MessageBox.Show("Row Updated Successfully.");
            //    LoadCustomers();
            //}
            //catch (Exception Ex)
            //{
            //    MessageBox.Show(Ex.Message);
            //    return;
            //}
        }
    }
    }
