﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for Matches.xaml
    /// </summary>
    public partial class Matches : Window
    {
        public Matches()
        {
            InitializeComponent();
        }

        //add

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try

            {

                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
               Match matchToBeAdded = new Trial.Match();
                matchToBeAdded.Match_Id = Convert.ToInt32(txt_matchid.Text);
                matchToBeAdded.Team_one_Id = Convert.ToInt32(txt_teamoneid.Text);
                matchToBeAdded.Team_two_Id= Convert.ToInt32(txt_teamtwoid.Text);
                matchToBeAdded.Venue_Id = Convert.ToInt32(txt_venueid.Text);
                matchToBeAdded.Schedule = txt_schedule.Text;

                if (matchToBeAdded != null)
                {
                    contextObj.Matches.Add(matchToBeAdded);

                    contextObj.SaveChanges();
                    MessageBox.Show("match Details Added");
                }

                else throw new Exception("match Id already exists!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //update

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try

            { 
            Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
          Match matchToBeSearched = new Trial.Match();


            int Match_Id = Convert.ToInt32(txt_matchid.Text);
            matchToBeSearched = contextObj.Matches.FirstOrDefault(match => match.Match_Id== Match_Id);

            if (matchToBeSearched != null)
            {
                matchToBeSearched.Team_one_Id = Convert.ToInt32(txt_teamoneid.Text);
                matchToBeSearched.Team_two_Id = Convert.ToInt32(txt_teamtwoid.Text);
                matchToBeSearched.Venue_Id = Convert.ToInt32(txt_venueid);
                matchToBeSearched.Schedule = txt_schedule.Text;
                contextObj.SaveChanges();
                MessageBox.Show("Match Details Updated");


            }
            else throw new Exception("match details does not exists!");
        }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
}

        //delete
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
                Match   matchToBeDeleted = new Trial.Match();

                int Match_Id = Convert.ToInt32(txt_matchid.Text);
                matchToBeDeleted = contextObj.Matches.FirstOrDefault(match => match.Match_Id == Match_Id);

                if (matchToBeDeleted != null)
                {
                    contextObj.Matches.Remove(matchToBeDeleted);//Delete operation
                    contextObj.SaveChanges();//Save the changes ack to the db
                    MessageBox.Show("match  Details Deleted");
                }
                else throw new Exception("Delete could not be done!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //search
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
              Match matchToBeSearched = new Trial.Match();

                int Match_Id = Convert.ToInt32(txt_matchid.Text);
                matchToBeSearched = contextObj.Matches.FirstOrDefault(match => match.Match_Id == Match_Id);


                if (matchToBeSearched != null)
                {
                   txt_teamoneid.Text = matchToBeSearched.Team_one_Id.ToString();
            txt_teamtwoid.Text = matchToBeSearched.Team_two_Id.ToString();
                   txt_venueid.Text = matchToBeSearched.Venue_Id.ToString();
                    txt_schedule.Text = matchToBeSearched.Schedule.ToString();
                    MessageBox.Show(" match Details Displayed");
                }
                else throw new Exception("match details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //display
        private void btnList_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();


            var query3 = from Match match in contextObj.Matches
                             //where team.Customer_Region == txt_custLocation.Text
                         select match;

            List<Match> mlist = new List<Trial.Match>();


            mlist = query3.ToList<Match>();
            if (mlist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            {
                dgmatch.ItemsSource = mlist;// query3.ToList();
            }
        }

        private void dgmatch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
