﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
          

        }

        //Team..
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

            Teams team_window = new Teams();
            team_window.Show();
            
            //MainWindow mw = new MainWindow();
            //mw.Show();
        }

        //Match..
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Matches Matches= new Matches();
            Matches.Show();
           
        }

        //Schedule..
        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
             Schedule MatchSchedule = new Schedule();
            MatchSchedule.Show();
          
        }

        //VEnue...
        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Venue place = new Venue();
            place.Show();
         
        }

        //Ticket..
        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            Ticket ticket = new Ticket();
            ticket.Show();
           
        }
        
        //TicketCategory...
        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            TicketCategoryWindow ticketCatg = new TicketCategoryWindow();
            ticketCatg.Show();
           
        }
    }
}
