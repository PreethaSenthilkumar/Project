﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for TicketCategoryWindow.xaml
    /// </summary>
    public partial class TicketCategoryWindow : Window
    {
        public TicketCategoryWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities6 contextObj = new Trial.Sep19CHNEntities6();
         TicketCategory ticket_categoryToBeAdded = new Trial.TicketCategory();
                ticket_categoryToBeAdded.TicketCategory_Id = Convert.ToInt32(txt_ticketcategoryid.Text);
                ticket_categoryToBeAdded.Category_Name = txt_categoryname.Text;
                ticket_categoryToBeAdded.Category_Description = txt_categorydescription.Text;

                if (ticket_categoryToBeAdded != null)
                {
                    //if (teamToBeAdded.Team_Id <= 8)
                    //{
                    contextObj.TicketCategories.Add(ticket_categoryToBeAdded);

                    contextObj.SaveChanges();
                    MessageBox.Show("Ticket Category Details Added");


                }
                else throw new Exception("Ticket category Id already exists!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Sep19CHNEntities6 contextObj = new Trial.Sep19CHNEntities6();
                TicketCategory categoryToBeSearched = new Trial.TicketCategory();


                int TicketCategory_Id = Convert.ToInt32(txt_ticketcategoryid.Text);
                categoryToBeSearched = contextObj.TicketCategories.FirstOrDefault(catg => catg.TicketCategory_Id == TicketCategory_Id);

                if (categoryToBeSearched != null)
                {
                    categoryToBeSearched.TicketCategory_Id = Convert.ToInt32(txt_ticketcategoryid.Text);
                    categoryToBeSearched.Category_Name = txt_categoryname.Text;
                    categoryToBeSearched.Category_Description = txt_categorydescription.Text;
                    contextObj.SaveChanges();
                    MessageBox.Show("Ticket Category Details Updated");


                }
                else throw new Exception("Team Category details does not exists!");


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities6 contextObj = new Trial.Sep19CHNEntities6();
                TicketCategory catgToBeDeleted = new Trial.TicketCategory();


                int TicketCategory_Id = Convert.ToInt32(txt_ticketcategoryid.Text);
                catgToBeDeleted = contextObj.TicketCategories.FirstOrDefault(catg => catg.TicketCategory_Id == TicketCategory_Id);

                if (catgToBeDeleted != null)
                {
                    contextObj.TicketCategories.Remove(catgToBeDeleted);//Delete operation
                    contextObj.SaveChanges();//Save the changes ack to the db
                    MessageBox.Show("Ticket Category Details Deleted");
                }
                else throw new Exception("Delete could not be done!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities6 contextObj = new Trial.Sep19CHNEntities6();
                TicketCategory categoryToBeSearched = new Trial.TicketCategory();


                int TicketCategory_Id = Convert.ToInt32(txt_ticketcategoryid.Text);
                categoryToBeSearched = contextObj.TicketCategories.FirstOrDefault(catg => catg.TicketCategory_Id == TicketCategory_Id);

                if (categoryToBeSearched != null)
                {
                    txt_ticketcategoryid.Text = categoryToBeSearched.TicketCategory_Id.ToString();
                    txt_categoryname.Text = categoryToBeSearched.Category_Name.ToString();
                    txt_categorydescription.Text = categoryToBeSearched.Category_Description.ToString();
                    MessageBox.Show("Category Details Displayed");
                }
                else throw new Exception("Category details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnList_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities6 contextObj = new Trial.Sep19CHNEntities6();


            var query3 = from TicketCategory catg in contextObj.TicketCategories
                             //where team.Customer_Region == txt_custLocation.Text
                         select catg;


            List<TicketCategory> tlist = new List<Trial.TicketCategory>();
            tlist = query3.ToList<TicketCategory>();
            if (tlist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            {
                dgcatg.ItemsSource = tlist;// query3.ToList();
            }
        }

        private void dgcatg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
