﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for Venue.xaml
    /// </summary>
    public partial class Venue : Window
    {
        public Venue()
        {
            InitializeComponent();
        }

        //add
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try

            {

                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
                Venue venueToBeAdded = new Trial.Venue();
                venueToBeAdded.Venue_Id = Convert.ToInt32(txt_venueid.Text);
                venueToBeAdded.VenueDescription= txt_venuedes.Text;
               
                if (venueToBeAdded != null)
                {
                    contextObj.Venues.Add(venueToBeAdded);

                    contextObj.SaveChanges();
                    MessageBox.Show("venue Details Added");
                }

                else throw new Exception("Venue Id already exists!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //update

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
                Venue venueToBeSearched = new Trial.Venue();



                int Venue_Id = Convert.ToInt32(txt_venueid.Text);
                venueToBeSearched = contextObj.Venues.FirstOrDefault(venue => venue.Venue_Id == Venue_Id);

                if (venueToBeSearched != null)
                {
                    venueToBeSearched.VenueDescription = txt_venuedes.Text;
                    
                    contextObj.SaveChanges();
                    MessageBox.Show("venue Details Updated");


                }
                else throw new Exception("venue details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //delete
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
               Venue venueToBeDeleted = new Trial.Venue();

                int Venue_Id = Convert.ToInt32(txt_venueid.Text);
                venueToBeDeleted = contextObj.Venues.FirstOrDefault(venue => venue.Venue_Id == Venue_Id);


                if (venueToBeDeleted != null)
                {
                    contextObj.Venues.Remove(venueToBeDeleted);//Delete operation
                    contextObj.SaveChanges();//Save the changes ack to the db
                    MessageBox.Show("venue Details Deleted");
                }
                else throw new Exception("Delete could not be done!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //search

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();
             Venue venueToBeSearched = new Trial.Venue();

                int Venue_Id = Convert.ToInt32(txt_venueid.Text);
                venueToBeSearched = contextObj.Venues.FirstOrDefault(venue => venue.Venue_Id == Venue_Id);

                if (venueToBeSearched != null)
                {
                  
                   txt_venuedes.Text = venueToBeSearched.txt_venuedes.ToString();
                    MessageBox.Show("venue Details Displayed");
                }
                else throw new Exception("venue details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //display

        private void btnList_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities1 contextObj = new Trial.Sep19CHNEntities1();


            var query3 = from Venue venue in contextObj.Venues
                             //where team.Customer_Region == txt_custLocation.Text
                         select venue;


            List<Venue> vlist = new List<Trial.Venue>();
            vlist = query3.ToList<Venue>();
            if (vlist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            {
                dgvenue.ItemsSource = vlist;// query3.ToList();
            }
        }

        private void dgvenue_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
