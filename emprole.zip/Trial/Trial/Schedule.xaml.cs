﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for Schedule.xaml
    /// </summary>
    public partial class Schedule : Window
    {
        public Schedule()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try

            {

                Sep19CHNEntities4 contextObj = new Trial.Sep19CHNEntities4();
              Schedule1 schdToBeAdded = new Trial.Schedule1();
                schdToBeAdded.scheduleslot = Convert.ToInt32(txt_schdslot.Text);
                schdToBeAdded.Match_Id = Convert.ToInt32(txt_matchid.Text);
                schdToBeAdded.Venue_Id = Convert.ToInt32(txt_venueid.Text);



                if (schdToBeAdded != null)
                {
                    contextObj.Schedule1.Add(schdToBeAdded);

                    contextObj.SaveChanges();
                    MessageBox.Show("Schedule Details Added");
                }

                else throw new Exception("already exists!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //to update
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Sep19CHNEntities4 contextObj = new Trial.Sep19CHNEntities4();
                Schedule1 schdToBeSearched = new Trial.Schedule1();


                int scheduleslot = Convert.ToInt32(txt_schdslot.Text);
                schdToBeSearched = contextObj.Schedule1.FirstOrDefault(schedule => schedule.scheduleslot == scheduleslot);

                if (schdToBeSearched != null)
                {

                    schdToBeSearched.scheduleslot = Convert.ToInt32(txt_schdslot.Text);
                    schdToBeSearched.Match_Id = Convert.ToInt32(txt_matchid.Text);
                    schdToBeSearched.Venue_Id = Convert.ToInt32(txt_venueid.Text);

                    contextObj.SaveChanges();
                    MessageBox.Show("Schedule Details Updated");


                }
                else throw new Exception("Schedule details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //delete
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities4 contextObj = new Trial.Sep19CHNEntities4();
                Schedule1 schdToBeDeleted = new Trial.Schedule1();

                int scheduleslot = Convert.ToInt32(txt_schdslot.Text);
                schdToBeDeleted = contextObj.Schedule1.FirstOrDefault(schedule => schedule.scheduleslot == scheduleslot);
                if (schdToBeDeleted != null)
                {
                    contextObj.Schedule1.Remove(schdToBeDeleted);//Delete operation
                    contextObj.SaveChanges();//Save the changes ack to the db
                    MessageBox.Show("schedule Details Deleted");
                }
                else throw new Exception("Delete could not be done!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities4 contextObj = new Trial.Sep19CHNEntities4();
                Schedule1 schdToBeSearched = new Trial.Schedule1();

                int scheduleslot = Convert.ToInt32(txt_schdslot.Text);
                schdToBeSearched = contextObj.Schedule1.FirstOrDefault(schedule => schedule.scheduleslot == scheduleslot);

                if (schdToBeSearched != null)
                {

                    txt_matchid.Text = schdToBeSearched.Match_Id.ToString();

                    txt_venueid.Text = schdToBeSearched.Venue_Id.ToString();
                
                    MessageBox.Show("schedule Details Displayed");
                }
                else throw new Exception("schedule details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }




        }

        private void btnList_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities4 contextObj = new Trial.Sep19CHNEntities4();


            var query3 = from Schedule1 schedule in contextObj.Schedule1
                             //where team.Customer_Region == txt_custLocation.Text
                         select schedule;


            List<Schedule1> slist = new List<Trial.Schedule1>();

            slist = query3.ToList<Schedule1>();
            if (slist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            {
                dgschedule.ItemsSource = slist;// query3.ToList();
            }
        }

        private void dgschedule_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
