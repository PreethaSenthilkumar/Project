﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trial
{
    /// <summary>
    /// Interaction logic for Ticket.xaml
    /// </summary>
    public partial class Ticket : Window
    {
        public Ticket()
        {
            InitializeComponent();
        }
        //add

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try

            {

                Sep19CHNEntities8 contextObj = new Trial.Sep19CHNEntities8();
           Ticket  ticketToBeAdded = new Trial.Ticket();
                ticketToBeAdded.Ticket_Id = Convert.ToInt32(txt_ticketid.Text);
                ticketToBeAdded.Match_Id = Convert.ToInt32(txt_matchid.Text);
                ticketToBeAdded.Price = Convert.ToInt32(txt_price.Text);
               

                if (ticketToBeAdded != null)
                {
                    contextObj.Tickets.Add(ticketToBeAdded);

                    contextObj.SaveChanges();
                    MessageBox.Show("ticket Details Added");
                }

                else throw new Exception("ticket Id already exists!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //search
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                
                    Sep19CHNEntities8 contextObj = new Trial.Sep19CHNEntities8();
                    Ticket ticketToBeSearched = new Trial.Ticket();


                    int Ticket_Id = Convert.ToInt32(txt_ticketid.Text);
                    ticketToBeSearched = contextObj.Tickets.FirstOrDefault(tic => tic.Ticket_Id == Ticket_Id);

                    if (ticketToBeSearched != null)
                    {
                        ticketToBeSearched.Match_Id = Convert.ToInt32(txt_matchid.Text);
                        ticketToBeSearched.Price = Convert.ToInt32(txt_price.Text);



                        contextObj.SaveChanges();
                        MessageBox.Show("ticket Details Updated");


                    }
                    else throw new Exception("Team details does not exists!");
                }
            


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //delete
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities8 contextObj = new Trial.Sep19CHNEntities8();
            Ticket ticketToBeDeleted = new Trial.Ticket();

                int Ticket_Id = Convert.ToInt32(txt_ticketid.Text);
                ticketToBeDeleted = contextObj.Tickets.FirstOrDefault(tic => tic.Ticket_Id == Ticket_Id);


                if (ticketToBeDeleted != null)
                {
                    contextObj.Tickets.Remove(ticketToBeDeleted);//Delete operation
                    contextObj.SaveChanges();//Save the changes ack to the db
                    MessageBox.Show("ticket Details Deleted");
                }
                else throw new Exception("Delete could not be done!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        


    }

        //search

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities8 contextObj = new Trial.Sep19CHNEntities8();
            Ticket ticketToBeSearched = new Trial.Ticket();


                int Ticket_Id = Convert.ToInt32(txt_ticketid.Text);

             
                ticketToBeSearched = contextObj.Tickets.FirstOrDefault(tic => tic.Ticket_Id == Ticket_Id);

                if (ticketToBeSearched != null)
                {

                    txt_matchid.Text= ticketToBeSearched.txt_matchid.ToString();
                    txt_price.Text = ticketToBeSearched.txt_price.ToString();
                   
                    MessageBox.Show("ticket Details Displayed");
                }
                else throw new Exception("ticket details does not exists!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //display


        private void btnList_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities8 contextObj = new Trial.Sep19CHNEntities8();


            var query3 = from Ticket  ticket in contextObj.Tickets
                             //where team.Customer_Region == txt_custLocation.Text
                         select ticket;


            List<Ticket> tklist = new List<Trial.Ticket>();
            tklist = query3.ToList<Ticket>();
            if (tklist.Count <= 0) { MessageBox.Show("No records found"); }


            else
            
                dgTicket.ItemsSource = tklist;// query3.ToList();
            
        }

        private void dgTicket_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
    }

